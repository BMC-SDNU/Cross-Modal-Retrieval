-- require 'OneHot'
vocab_size = 0
function mysplit(inputstr, sep)
        if sep == nil then
                sep = "%s"
        end
        local t={} ; i=1
        for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
                t[i] = str
                i = i + 1
        end
        return t
end
-- dict
function read_dict()
    path = 'coco_dic.txt'
    local file = io.open(path, 'r')
    if file then print("File exist") end
    for line in file:lines() do
        print(#line)
        dict_ = mysplit(line, ' ')
        vocab_size = #dict_
        print (#dict_)
    end
    dict_number = {}
    for data_ = 1, #dict_ do
        dict_number[dict_[data_]] = data_
    end
    return dict_number
end

dict_number = read_dict()

function extract_one_hot(input) -- input is a sentence
    word_list = mysplit(input, ' ')
    output = torch.Tensor(#word_list, vocab_size):zero()
    for word_ = 1, #word_list do
        num_idx = dict_number[word_list[word_]]
        print (num_idx)
        tmp = torch.Tensor(vocab_size):zero()
        tmp[num_idx] = 1
        output[word_] = tmp:clone()
    end
    return output
end
aaaa = 'a boy is running'
aaaa_onehot = extract_one_hot(aaaa)
print (#aaaa_onehot)
