require "hdf5"
require 'nn'
h5_file = "/home/xinge/Experiments/EmoNet/feature_extract/train_20000.h5"
h5_test_file = "/home/xinge/Experiments/EmoNet/feature_extract/test_random.h5"

h5_reader = hdf5.open(h5_file, 'r')

local image_size = h5_reader:read("/images"):dataspaceSize()
print (image_size)

local label_size = h5_reader:read("/labels"):dataspaceSize()
print (label_size)
aa = h5_reader:read("/labels"):partial({1,10},1)
print (aa)
-- -- bb = nn.Replicate(5,2):forward(aa)
-- -- bb = {}
-- -- for i = 1,5 do
-- --     table.insert(bb, aa)
-- -- end
-- -- print (bb)
-- local img_feature = h5_reader:read("/images"):partial({1,64},{1,5}, {1,512})
-- print (#img_feature)
-- print (img_feature[{1,{1,2},{1,20}}])
-- -- local img_feature_2 = h5_reader:read("/images"):partial({1,64})
-- -- print ("img_feature_2:" .. #img_feature_2)
--
-- h5_reader_test = hdf5.open(h5_test_file, 'r')
-- local image_test_fea = h5_reader_test:read("/labels"):partial({1,64},1)
-- print ("image_test_fea")
-- print (image_test_fea)
local dataloader = {}

dataloader.__index = dataloader


function dataloader.create(batch_size,seq_length)
    local self ={}
    setmetatable(self, dataloader)
    self.batch_size = batch_size
    self.train_h5 = hdf5.open(h5_file, 'r')
    self.val_h5 = hdf5.open(h5_test_file, 'r')
    self.batch_idx = {0,0} -- train and val idx
    self.seq_length = seq_length
    self.train_size = self.train_h5:read('/images'):dataspaceSize()
    self.val_size = self.val_h5:read('/images'):dataspaceSize()
    self.image_size = {self.train_size[1], self.val_size[1]}
    self.data = {self.train_h5, self.val_h5}
    collectgarbage()
    return self
end


function dataloader:reset(split_idx)
    self.batch_idx[split_idx] = 0
end

function dataloader:next_batch(split_idx) -- split_idx, 1 for train 2 for avl
    start_idx = self.batch_idx[split_idx] * self.batch_size + 1
    end_idx = (self.batch_idx[split_idx] + 1) * self.batch_size

    if end_idx > self.image_size[split_idx]+1 then
        self.batch_idx[split_idx] = 0
        start_idx = self.batch_idx[split_idx] * self.batch_size
        end_idx = (self.batch_idx[split_idx] + 1) * self.batch_size
    end

    self.batch_idx[split_idx] = self.batch_idx[split_idx] + 1
    if start_idx == 0 then
        start_idx = 1
    end
    -- end_idx = end_idx
    -- print ("start_idx " .. start_idx)
    -- print ("end_idx " .. end_idx)
    data_fea = self.data[split_idx]:read("/images"):partial({start_idx,end_idx},{1,self.seq_length},{1,512})
    data_label = self.data[split_idx]:read("/labels"):partial({start_idx,end_idx},1)
    return data_fea, data_label
end

return dataloader
