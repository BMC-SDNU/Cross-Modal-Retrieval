--[[

1. dataloader create
2. network create
3. clone network
4. train network
5. optimize network

]]--
require 'torch'
require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'cutorch'

require 'lfs'
require 'optim'
require 'txt-model.misc'
local model_utils = require 'txt-model.model_utils'
local LSTM = require 'txt-model.LSTM'

--model params
local lstm_train = {}
local optim_state = {}
local para ={}
para.rnn_size = 512     --size of LSTM internal state
para.input_size = 512   --input size of lst
para.num_layers = 2   --number of layers
para.model = 'lstm'     --lstm or gru
para.seq_length = 8     --number of timesteps to roll up
para.batch_size = 1     --size of a batch

-- optim params
para.learning_rate = 2e-3 --learning rate
para.learning_rate_decay = 0.97--learning rate decay
para.decay_rate = 0.9 --decay rate for rmsprop
para.learning_rate_decay_after = 10 --in number of epochs, when to start decaying the learning rate
para.learning_rate_decay_after_batch = 2000 --in number of epochs, when to start decaying the learning rate
para.dropout = 0.1 --dropout for regularization, used after each RNN output layer
para.max_epochs = 10 --max size of epochs
para.grad_clip = 8 --clip gradients

-- train params
para.init_from = '' --initialize a network from this checkpoint
para.seed = 123 --random feed generator
para.eval_val_every = 500 --how long to check the loss
para.save_ck_every = 5000 --how long to check the loss
para.checkpoint_dir = './checkpoint/' --dir of saving the model
para.saveid = 1 --the id of saved model
para.print_every = 100 --how many steps/minibatches between printing out the loss
para.epsilon = 1e-8
para.alpha = 0.8

-- GPU
para.gpuid = 0;
--cmd:option('-gpuid', 0, 'gpu id')

opt = para

if opt.gpuid >= 0 then
    cutorch.setDevice(opt.gpuid + 1)
    cutorch.manualSeed(opt.seed)
end

local do_random_init = true


lstm_train.protos = {}
if opt.model == 'lstm' then
    print ("create the model from scratch ")
    lstm_train.protos.rnn = LSTM.lstm(opt.input_size, opt.rnn_size, opt.num_layers, opt.dropout)
elseif opt.model == 'gru' then
    lstm_train.protos.rnn = GRU.gru(opt.input_size, opt.rnn_size, opt.num_layers, opt.dropout)
end
lstm_train.protos.criterion = nn.ClassNLLCriterion()

-- init the cell/hidden states
init_state = {}
for L = 1, opt.num_layers do
    local h_init = torch.zeros(opt.batch_size, opt.rnn_size):cuda()
    table.insert(init_state, h_init:clone())
    if opt.model == 'lstm' then
        table.insert(init_state, h_init:clone())
    end
end

if opt.gpuid >=0 then
    for k,v in pairs(lstm_train.protos) do
        v:cuda()
    end
end

params, grad_params = model_utils.combine_all_parameters(lstm_train.protos.rnn)

if do_random_init == true then
    params:uniform(-0.08, 0.08)
end

if opt.model == 'lstm' then
    for layer_idx = 1, opt.num_layers do
        for _, node in ipairs(lstm_train.protos.rnn.forwardnodes) do
            if node.data.annotations.name == 'i2h_' .. layer_idx then
                -- set the bias of forget gate to 1
                node.data.module.bias[{{opt.rnn_size+1,2*opt.rnn_size}}]:fill(1.0)
            end
        end
    end
end

print ("the total number of params in the network:" .. params:nElement())


clones = {}
for name, proto in pairs(lstm_train.protos) do
    print ("cloning " .. name)
    clones[name] = model_utils.clone_many_times(proto, opt.seq_length, not proto.parameters)
end

function rmsprop(x, dx, lr, alpha, epsilon, state)
      if not state.m then
        state.m = x.new(#x):zero()
        state.tmp = x.new(#x)
      end
      -- calculate new (leaky) mean squared values
      state.m:mul(alpha)
      state.m:addcmul(1.0-alpha, dx, dx)
      -- perform update
      state.tmp:sqrt(state.m):add(epsilon)
      x:addcdiv(-lr, dx, state.tmp)
end

function preprocessed(x)
    -- swap the axis for fast training
    x = x:transpose(1,2):contiguous() -- batch 和 seq_length互换位置
    x = x:float():cuda()
    return x
end

local init_state_global = clone_list(init_state) 

function lstm_train.forward(txt_mat, length, max_batches)
    local rnn_state = {[0] = init_state}
    local fea = {}
    for i = 1, max_batches do
        x = txt_mat:clone()
        x = preprocessed(x)
        for t = 1, length do
            clones.rnn[t]:training()
            lst = clones.rnn[t]:forward{x[t], unpack(rnn_state[t-1])}
            rnn_state[t] = {}
            for i=1, #init_state do table.insert(rnn_state[t], lst[i]) end
            table.insert(fea, lst[#lst])
        end
    end

    return fea, rnn_state
end

function lstm_train.backward(txt_mat, doutput_lstm, rnn_state)
    local h_init = torch.zeros(opt.batch_size, opt.rnn_size):cuda()
    grad_params:zero()
    x = txt_mat:clone()
    x = preprocessed(x)
    dlook_up_table = torch.DoubleTensor(8,512)
    local drnn_state = {[opt.seq_length] = clone_list(init_state, true)}
    for t = opt.seq_length, 1, -1 do
        local tmp_ls = doutput_lstm[t]:clone():resize(1,512)
        --table.insert(drnn_state[t], tmp_ls)
        drnn_state[t][4] = tmp_ls
        local dlst = clones.rnn[t]:backward({x[t], unpack(rnn_state[t-1])}, drnn_state[t])
        drnn_state[t-1] = {}

        for k,v in pairs(dlst) do
            if k>1 then 
                drnn_state[t-1][k-1] = v
            end
        end
        dlook_up_table[t] = dlst[1]:clone():resize(512):double()
    end
    init_state_global = rnn_state[#rnn_state]
    grad_params:clamp(-opt.grad_clip, opt.grad_clip)
    rmsprop(params,grad_params,opt.learning_rate, opt.alpha, opt.epsilon, optim_state)
    return dlook_up_table
end

return lstm_train

