import json
import os
import sys

file = "/home/zhangliang/my-work/coco_training_file/all_text.txt"
save_path = "/home/zhangliang/my-work/coco_training_file/coco_dic.txt"

coco_dic = []
with open(save_path, 'wb') as w:
	with open(file, 'rb') as f:
		lines = f.readlines()
		for i in lines:
			if i.strip()=='':
 				continue
			else:
				words = i.strip().split(' ')
				for j in words:
					if j == '':
						continue
					else:
						if (j[-1]=='.')or(j[-1]==',')or(j[-1]=='?')or(j[-1]=='!'):
							new=j[:-1]
						else:
							new=j
						if (not new in coco_dic):
							coco_dic.append(new)				
							w.write(new)
							w.write(' ')
