# To handle each caption, which move the punctuation and other symbols
import json
import os
import sys

#file = "/home/zhang/datasets/coco/annotations/captions_train2014.json"
#file1 = "/home/zhang/datasets/coco/annotations/instances_train2014.json"

file = "/home/zhang/datasets/coco/annotations/captions_val2014.json"
file1 = "/home/zhang/datasets/coco/annotations/instances_val2014.json"

def del_sym(caps):
	tmp_cap = []
	if caps.strip()=='':
		return 0
	else:
		words = caps.strip().split(' ')
		for j in words:
			if j == '':
				continue
			else:
				if (j[-1]=='.')or(j[-1]==',')or(j[-1]=='?')or(j[-1]=='!'):
					j=j[:-1]
					tmp_cap.append(j)
				else:
					j=j
					tmp_cap.append(j)
#	print tmp_cap
	return tmp_cap

with open(file1, 'rb') as f1:
	dict2 = json.load(f1);
	print dict2.keys()
	print dict2['images'][0]
	print dict2['categories'][-1]['name']
	# print dict2['info']
#	for idx in range 

with open(file, 'rb') as f:
	dict1 = json.load(f)
	print dict1.keys()
	print dict1['images'][0]


	print dict1['annotations'][0]
	print len(dict1['images']), len(dict1['annotations'])

	image_id = {} # id, name
	cap_image = {} # id, ["","","","",""]

	for idx in range(0, len(dict1['images'])):
		id_1 = dict1['images'][idx]['id']
		name = dict1['images'][idx]['file_name']
		image_id[id_1] = name
	#print image_id[318556]
	for idx in range(0,len(dict1['annotations'])):
		id_2 = dict1['annotations'][idx]['image_id']
		if cap_image.has_key(id_2) == False:
			cap_image[id_2] = []
		cap_image[id_2].append(dict1['annotations'][idx]['caption'])


	#dir_path = "/home/zhang/my-work/coco_train_captions/"
	dir_path = "/home/zhang/my-work/coco_val_captions/"
	for keys in cap_image.keys():
		caps = cap_image[keys]
		path = image_id[keys]
		
		path = path.split(".")[0] + ".txt"
		print path
		real_path = os.path.join(dir_path, path)
		with open(real_path, 'wb') as w:
			for idxxx in range(0,len(caps)):
				print caps[idxxx]
				tmp_caps = del_sym(caps[idxxx])
				for wd in tmp_caps:
					w.write(wd)
					w.write(" ")
				w.write("\n")
			w.close()

